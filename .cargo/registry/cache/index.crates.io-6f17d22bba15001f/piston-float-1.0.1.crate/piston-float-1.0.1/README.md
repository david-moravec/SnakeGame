# float
Traits for generic floats in game development
