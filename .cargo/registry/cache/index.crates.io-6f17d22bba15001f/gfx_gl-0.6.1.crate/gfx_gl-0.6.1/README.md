gfx_gl
======

[![Build Status](https://travis-ci.org/gfx-rs/gfx_gl.png?branch=master)](https://travis-ci.org/gfx-rs/gfx_gl)
[![Crates.io](https://img.shields.io/crates/v/gfx_gl.svg)](https://crates.io/crates/gfx_gl)

An OpenGL loader tailored to gfx-rs's needs.
