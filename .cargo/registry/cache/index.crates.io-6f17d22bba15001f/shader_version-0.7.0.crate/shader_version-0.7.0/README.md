# shader_version [![Build Status](https://travis-ci.org/PistonDevelopers/shader_version.svg?branch=master)](https://travis-ci.org/PistonDevelopers/shader_version)

A helper library for detecting and picking compatible shaders.

Maintainers: @TyOverby, @bvssvni

[How to contribute](https://github.com/PistonDevelopers/piston/blob/master/CONTRIBUTING.md)
