gfx_texture [![Build Status](https://travis-ci.org/PistonDevelopers/gfx_texture.svg?branch=master)](https://travis-ci.org/PistonDevelopers/gfx_texture)
===========

A Gfx texture representation that works nicely with Piston libraries

[How to contribute](https://github.com/PistonDevelopers/piston/blob/master/CONTRIBUTING.md)
